library(shiny) 
library(tidyverse)
library(cowplot)
library(here)

# 2.
# Laod the milk_production.csv into this file.
# Create a sidebar layout.
# Name the title "Milk Production"
# Create a select box with all the choices of regions in the milk production.
# Launch the app.


ui <- fluidPage(
 
)

# 3.
# Creata a plot to display the trend (use lines) of milk production, which allows us to choose different region.
# Launch the app.

server <- function(input, output){

}

shinyApp(ui = ui, server = server)



