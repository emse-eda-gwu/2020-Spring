library(shiny)

# install.packages("shiny")

# Launch the app
# Change the title from "Hello Shiny!" to "Hello World!".
# Set the minimum value of slider bar to 5.
# Change the histogram border color from "white" to "orange".
# Relaunch the app to change the change.

ui <- fluidPage(
  titlePanel("Hello World!"),
  sidebarLayout(
    sidebarPanel(
      sliderInput(inputId = "bins",
                  label = "Number of bins:",
                  min = 1,
                  max = 50,
                  value = 30)
    ),
    
    mainPanel(
      h3("Bar Plot of Number of Bins"),
      plotOutput(outputId = "distPlot")
    )
  )
)

server <- function(input, output){
  output$distPlot <- renderPlot({
     
    x <- faithful$waiting # faithful is a build-in dataset in R
    bins <- seq(min(x), max(x), length.out = input$bins + 1)
    
    hist(x, breaks = bins, col = "#75AADB", border = "white",
         xlab = "Waiting time to next eruption(in mins)", 
         main = "Histogram of waiting times")
  })
}

shinyApp(ui = ui, server = server) 
