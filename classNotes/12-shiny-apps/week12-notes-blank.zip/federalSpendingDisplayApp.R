library(shiny)

# load the data
federal_spending <- read_csv(here::here('data', 'federal_spending_long.csv'))

ui <- fluidPage(
  titlePanel("Federal Spending"),
  
  sidebarLayout(
    sidebarPanel(
      
      selectInput("department", # input name
                  label = "Choose a department to display",
                  choices = c("DOD", 
                              "NASA",
                              "DOE",
                              "HHS",
                              "NIH",
                              "NSF",
                              "USDA",
                              "Interior",
                              "DOT",
                              "EPA",
                              "DOC",
                              "DHS",
                              "VA",
                              "Other"),
                  selected = "DOD")
    ),
    
    mainPanel(
      plotOutput("barPlot") # output name
    )
  )
)

server <- function(input, output){
  output$barPlot <- renderPlot({
    inputDepartment <- switch (input$department,
                               "DOD" = "DOD",
                               "NASA" = "NASA",
                               "DOE" = "DOE",
                               "HHS" = "HHS",
                               "NIH" = "NIH",
                               "NSF" = "NSF",
                               "USDA" = "USDA",
                               "Interior" = "Interior",
                               "DOT" = "DOT",
                               "EPA" = "EPA",
                               "DOC" = "DOC",
                               "DHS" = "DHS",
                               "VA" = "VA",
                               "Other" = "Other"
    )
    federal_spending %>% filter(department == inputDepartment) %>% 
      ggplot(aes(x = year, y = rd_budget)) + 
      geom_col(fill = "steelblue", width = 0.7, alpha = 0.8) +
      theme_half_open(font_size = 18) +
      labs(x = "Year",
           y = "Federal Spending",
           title = paste("Federal Spending in", inputDepartment))
    
  }) 
}

shinyApp(ui = ui, server = server)
