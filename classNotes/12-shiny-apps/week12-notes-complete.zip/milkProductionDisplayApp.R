library(shiny) 
library(tidyverse)
library(cowplot)
library(here)

# 2.
# Laod the milk_production.csv into this file.
# Create a sidebar layout.
# Name the title "Milk Production"
# Create a select box with all the choices of regions in the milk production.
# Launch the app.

milk_production <- read_csv(here::here('data', 'milk_production.csv'))

ui <- fluidPage(
  titlePanel("Milk Production"),
  
  sidebarLayout(
    sidebarPanel(
      
      selectInput("region", # input name
                  label = "Choose a region to display",
                  choices = c("Northeast", 
                              "Lake States",
                              "Corn Belt",
                              "Northern Plains",
                              "Appalachian",
                              "Southeast",
                              "Delta States",
                              "Southern Plains",
                              "Mountain",
                              "Pacific"),
                  selected = "Northeast")
    ),
    
    mainPanel(
      plotOutput("linePlot") # output name
    )
  )
  
)

# 3.
# Creata a plot to display the trend(only use line) of milk production, which can choose different region.
# Launch the app.

server <- function(input, output){
  output$linePlot <- renderPlot({
    inputRegion <- switch (input$region,
                           "Northeast" = "Northeast",
                           "Lake States" = "Lake States",
                           "Corn Belt" = "Corn Belt",
                           "Northern Plains" = "Northern Plains",
                           "Appalachian" = "Appalachian",
                           "Southeast" = "Southeast",
                           "Delta States" = "Delta States",
                           "Southern Plains" = "Southern Plains",
                           "Mountain" = "Mountain",
                           "Pacific" = "Pacific"
    )
    
    milk_production %>% filter(region == inputRegion) %>%
      ggplot(aes(x = year, y = milk_produced, col = state)) +
      geom_line(size = 1) +
      coord_cartesian(clip = 'off') +
      theme_half_open(font_size = 18) +
      labs(x = "Year",
           y = "Milk produced (billion lbs)",
           title = paste("Milk production in ", inputRegion))
  })  
}

shinyApp(ui = ui, server = server)



