# This is a .R file, not a .Rmd file. That means you can only write code here.
# If you want to write some text, you have to write them in comments with the
# "#" symbol.

# This file can is meant to help you in writing code to clean and explore your
# data and create some plots. Most of the time, coming up with the final
# format of your "cleaned" data and polished charts will involve many
# iterations. It is often easier to start here and just work on getting your
# code working correctly before going over to the report.Rmd file where you
# will want to only include the final format of your code.

# The report.Rmd file is written for your audience so they can read and
# understand your analysis. This file is for you to do the messy work of
# debugging and getting your code working. You don't need to include this file
# at all for your report - that's why it's called "sketchpad"

library(tidyverse)
library(here)
